FX TRADE ASSIST - Android APKプロジェクト

【内容】
- USD/JPY、15分足を初期想定
- EMA20/50、ストキャスティクス9・3・3、RSI14で買い/売り/様子見の補助判定
- 資金、許容損失、損切り幅、利益目標から数量と概算損益を計算
- ネット接続・口座ログイン・自動発注なし

【APKのビルド方法】
1. PCに Android Studio（最新版）をインストール
2. Android Studioでこのフォルダ FX_TRADE_ASSIST を開く
3. Gradle同期を実行（初回はインターネット接続が必要）
4. Build > Build Bundle(s) / APK(s) > Build APK(s) を選択
5. 完成したAPKは app/build/outputs/apk/debug/app-debug.apk
6. APKをAndroid端末へ転送してインストール。端末側で必要に応じ「この提供元のアプリを許可」を有効化

【注意】
この配布物はAndroid StudioでAPKを生成するためのソースプロジェクトです。APKバイナリそのものではありません。この実行環境にはAndroid SDK/Gradleビルド環境がないため、APKのコンパイル・署名は実施していません。

【取引上の注意】
判定は手入力された指標値に依存します。確定足で判定し、エントリー前に必ず損切り注文を設定してください。利益や勝率を保証するものではありません。
