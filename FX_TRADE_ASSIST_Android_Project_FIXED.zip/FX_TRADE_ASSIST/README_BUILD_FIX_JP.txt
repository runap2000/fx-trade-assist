FX TRADE ASSIST Android build fix

今回のGitHub Actionsエラーは、Javaコンパイルの出力先が1.8、Kotlinが17になっていたことが原因です。
app/build.gradle に次の設定を追加し、両方をJava 17に統一しています。

compileOptions {
    sourceCompatibility JavaVersion.VERSION_17
    targetCompatibility JavaVersion.VERSION_17
}
kotlinOptions {
    jvmTarget = '17'
}

GitHubでは既存の FX_TRADE_ASSIST_Android_Project.zip をこの修正版ZIPで置き換えてください。
置き換え後、Actionsから「Build FX TRADE ASSIST APK」を再実行します。

注意：このZIPはソースプロジェクトです。APKそのものではありません。
